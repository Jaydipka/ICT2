﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqDemo
{
    class Program
    {
        static void Main1(string[] args)
        {
            int[] nums = new int[] { 0, 4, 2, 6, 3, 8, 3, 1 };
            //double average = nums.Take(6).Average();
            double average = nums.Skip(3).Take(3).Average();
            Console.WriteLine("average is" + average);
            var above = from n in nums
                        where n > average
                        select n;

            var aboveX = nums.Where(v => v > average);
            foreach (int x in above)
            {
                Console.WriteLine(x.ToString());
            }

            Console.ReadKey();


        }

        static void Main2(string[] args)
        {
            int[] numListA = new int[] { 0, 5, 2, 6, 9, 8, 7, 4 };


            int[] numListB = new int[] { 12, 45, 11, 22, 85, 74, 96 };

            var combine = numListA.Union(numListB);

        }

        static void Main(string[] args)
        {
            int[] nums = new int[] { 0, 1, 4, 5, 3, 6, 5, 2 };
            Console.WriteLine("Is contains 2?" + nums.Contains(2));
            Console.WriteLine("Is contains 12?" + nums.Contains(12));
            Console.WriteLine("Is any vlaue divisible by 5?" + nums.Any(x))
        }


    }
}