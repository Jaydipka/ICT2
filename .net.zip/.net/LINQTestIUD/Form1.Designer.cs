﻿
namespace LINQTestIUD
{
    partial class update
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.add = new System.Windows.Forms.Button();
            this.pname = new System.Windows.Forms.TextBox();
            this.pquntity = new System.Windows.Forms.TextBox();
            this.pcategories = new System.Windows.Forms.TextBox();
            this.prate = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.delete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(36, 22);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(724, 131);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // add
            // 
            this.add.Location = new System.Drawing.Point(36, 399);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(75, 23);
            this.add.TabIndex = 1;
            this.add.Text = "ADD";
            this.add.UseVisualStyleBackColor = true;
            this.add.Click += new System.EventHandler(this.button1_Click);
            // 
            // pname
            // 
            this.pname.Location = new System.Drawing.Point(36, 199);
            this.pname.Name = "pname";
            this.pname.Size = new System.Drawing.Size(100, 20);
            this.pname.TabIndex = 4;
            this.pname.Text = "ProductName";
            this.pname.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // pquntity
            // 
            this.pquntity.Location = new System.Drawing.Point(412, 199);
            this.pquntity.Name = "pquntity";
            this.pquntity.Size = new System.Drawing.Size(100, 20);
            this.pquntity.TabIndex = 5;
            this.pquntity.Text = "ProductQuntity";
            // 
            // pcategories
            // 
            this.pcategories.Location = new System.Drawing.Point(294, 199);
            this.pcategories.Name = "pcategories";
            this.pcategories.Size = new System.Drawing.Size(100, 20);
            this.pcategories.TabIndex = 6;
            this.pcategories.Text = "ProductCategories";
            // 
            // prate
            // 
            this.prate.Location = new System.Drawing.Point(169, 199);
            this.prate.Name = "prate";
            this.prate.Size = new System.Drawing.Size(100, 20);
            this.prate.TabIndex = 7;
            this.prate.Text = "ProductRate";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(208, 399);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "UPDATE";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // delete
            // 
            this.delete.Location = new System.Drawing.Point(385, 399);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(75, 23);
            this.delete.TabIndex = 9;
            this.delete.Text = "DELETE";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // update
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.prate);
            this.Controls.Add(this.pcategories);
            this.Controls.Add(this.pquntity);
            this.Controls.Add(this.pname);
            this.Controls.Add(this.add);
            this.Controls.Add(this.dataGridView1);
            this.Name = "update";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.TextBox pname;
        private System.Windows.Forms.TextBox pquntity;
        private System.Windows.Forms.TextBox pcategories;
        private System.Windows.Forms.TextBox prate;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button delete;
    }
}

