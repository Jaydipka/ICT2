﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LINQTestIUD
{
    public partial class update : Form
    {
        public update()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            GroProductDataContext dc = new GroProductDataContext();
            dataGridView1.DataSource = dc.GroProducts;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GroProductDataContext gp = new GroProductDataContext();
            GroProduct groproduct = new GroProduct();
            groproduct.ProductName = pname.Text;
            groproduct.ProductRate = Int32.Parse(prate.Text);
            groproduct.ProductQuntity = Int32.Parse(pquntity.Text);
            groproduct.ProductCategories = Int32.Parse(pcategories.Text);

            gp.GroProducts.InsertOnSubmit(groproduct);
            gp.SubmitChanges();

            GroProductDataContext dc = new GroProductDataContext();
            dataGridView1.DataSource = dc.GroProducts;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void delete_Click(object sender, EventArgs e)
        {

        }
    }
}
