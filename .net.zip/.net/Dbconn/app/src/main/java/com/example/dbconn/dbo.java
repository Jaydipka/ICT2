package com.example.dbconn;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class dbo extends SQLiteOpenHelper {
    public dbo(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "Student", factory, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
    sqLiteDatabase.execSQL("create table stud(sid integer primary key autoincrement,sname text, sage integer)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists student");
        onCreate(sqLiteDatabase);
    }
    public  void  addData(String n, Integer a)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv= new ContentValues();
        cv.put("sname",n);
        cv.put("sage",a);
        db.insert("stud",null, cv);
        db.close();
    }
    public void del_rec()
    {

        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("stud","sid=?", new  String[] {String.valueOf(2)});
    }
    public Cursor getdata()
    {
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cur = db.rawQuery("select * from stud", null);
        return  cur;
    }
}
