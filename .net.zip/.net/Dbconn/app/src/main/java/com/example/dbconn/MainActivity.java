package com.example.dbconn;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText ed;
    EditText ed2;
    Button btn;
    ListView listView;

    dbo obj=new dbo(this, "Student", null, 1);
    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed = findViewById(R.id.editTextTextPersonName);
        ed2 = findViewById(R.id.editTextTextPersonName2);
        btn = findViewById(R.id.button);
        listView = findViewById(R.id.listview);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                obj.addData(ed.getText().toString(),Integer.parseInt(ed2.getText().toString()));
            }
        });
        //obj.del_rec();
//
        StringBuilder sb=new StringBuilder();
        Cursor result;
        result=obj.getdata();

        while (result.moveToNext())
        {

            //sb.append(result.getColumnName("sname"));
            sb.append(result.getString(result.getColumnIndex("sname")));
        }
        Toast.makeText(this, sb, Toast.LENGTH_SHORT).show();
    }
}