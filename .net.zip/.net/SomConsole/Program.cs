﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomConsole
{
    class Program
    {
        static void Main(string[] args)
        {

				int x = 400;
				int y = 60;
				

				void AddValue(int a, int b)
				{
					Console.WriteLine("Value of a is:" + a);
					Console.WriteLine("Value of b is:" + b);
					Console.WriteLine("Value of x is:" + x);
					Console.WriteLine("Value of y is:" + y);
					Console.WriteLine("sum: {0}", a + b + x + y);
					Console.WriteLine();
					Console.ReadKey();
				}
				AddValue(500, 60);
				AddValue(79, 700);
				

		}
	}
}
